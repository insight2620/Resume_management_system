package com.resume.dao;


import com.resume.bean.Admin;
import com.resume.jdbc.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class AdminDao {
	public Admin check(String id,String password) {
		Admin Admin = null;
		String sql ="select * from admin where userid= '"+id+"'and password='"+password+"';";
		Connection connection= jdbc.getConn();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			statement= connection.createStatement();
			resultSet = statement.executeQuery(sql);
			if(resultSet.next())Admin = new Admin(id,password);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			jdbc.close(connection, statement, resultSet);
		}
		return Admin;
	}
	
	public Admin checkId(String id) {
		Admin Admin = null;
		String sql ="select * from admin where userid= '"+id+"';";
		Connection connection= jdbc.getConn();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			statement= connection.createStatement();
			resultSet = statement.executeQuery(sql);
			if(resultSet.next())Admin=new Admin(id,resultSet.getString(2));
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			jdbc.close(connection, statement, resultSet);
		}
		return Admin;
	}
	
	public void update(Admin user) {
		String sql ="update admin set password='"+user.getPassword()+"' where userid='"+user.getUserid()+"';";
		Connection connection= jdbc.getConn();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			statement= connection.createStatement();
			statement.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			jdbc.close(connection, statement, resultSet);
		}
	}
	
}