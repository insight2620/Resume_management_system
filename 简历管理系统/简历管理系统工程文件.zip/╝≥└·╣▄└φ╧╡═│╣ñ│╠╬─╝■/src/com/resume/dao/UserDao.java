package com.resume.dao;


import com.resume.bean.User;
import com.resume.jdbc.jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class UserDao {
	
	public void add(String id,String password) {
		String sql = "insert  into user values('"+id+"','"+password+"');";
		Connection connection= jdbc.getConn();
		Statement statement = null;
		try {
			statement= connection.createStatement();
			statement.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			jdbc.close(connection, statement, null);
		}
	}
	
	public User check(String id,String password) {
		User user = null;
		String sql ="select * from user where userid= '"+id+"'and password='"+password+"';";
		Connection connection= jdbc.getConn();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			statement= connection.createStatement();
			resultSet = statement.executeQuery(sql);
			if(resultSet.next())user = new User(id,password);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			jdbc.close(connection, statement, resultSet);
		}
		return user;
	}
	
	public User checkId(String id) {
		User user = null;
		String sql ="select * from user where userid= '"+id+"';";
		Connection connection= jdbc.getConn();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			statement= connection.createStatement();
			resultSet = statement.executeQuery(sql);
			if(resultSet.next())user=new User(id,resultSet.getString(2));
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			jdbc.close(connection, statement, resultSet);
		}
		return user;
	}
	
	public void update(User user) {
		String sql ="update user set password='"+user.getPassword()+"' where userid='"+user.getUserid()+"';";
		Connection connection= jdbc.getConn();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			statement= connection.createStatement();
			statement.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			jdbc.close(connection, statement, resultSet);
		}
	}
	/*public static void main(String []args) {
		 UserDao userDao = new UserDao();
//		 userDao.add("1", "123");
//		 User user =userDao.check("1", "123");
//		 System.out.println(user);
//		 user.setPassword("123456");
//		 userDao.update(user);
//		 user = userDao.checkId(user.getUserid());
//		 System.out.println(user);
		 User user = userDao.check("admin","123");
		 System.out.println(user);
		 
	}*/
}
