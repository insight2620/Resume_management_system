package com.resume.dao;

import com.resume.bean.User;
import com.resume.jdbc.jdbc;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class usershow {
	public void delete(String id) {
		String sql = "delete from user where userid='" + id + "';";
		Connection connection = jdbc.getConn();
		Statement statement = null;
		try {
			statement = connection.createStatement();
			statement.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			jdbc.close(connection, statement, null);
		}
	}

	public int count(String sql) {
		int a = 0;
		Connection connection = jdbc.getConn();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);
			if(resultSet.next())a = resultSet.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			jdbc.close(connection, statement, null);
		}
	    return a;
	}

	public User getById(String id) {
		User User = null;
		String sql = "select * from user where userid='"+id+"';";
		Connection connection = jdbc.getConn();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);
			if(resultSet.next())User  = new User( resultSet.getString(1),resultSet.getString(2));
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			jdbc.close(connection, statement, null);
		}
	    return User;
	}
	
	public List<User> getAll(){
		List <User> list = new ArrayList<>();
		String sql = "select userid,password from user";
		Connection connection = jdbc.getConn();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);

			while(resultSet.next()){
				User usertemp = new User();
				usertemp.setUserid(resultSet.getString(1));
				usertemp.setPassword(resultSet.getString(2));
				list.add(usertemp);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			jdbc.close(connection, statement, null);
		}
	    return list;
	}

	public void addone(User user)
	{
		String sql = "insert into user values(" +
				 user.getUserid()+
				"," +user.getPassword()+
				")";
		Connection connection = jdbc.getConn();
		Statement statement = null;
		try {
			statement = connection.createStatement();
			statement.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			jdbc.close(connection, statement, null);
		}

	}
}