package com.resume.dao;

import com.resume.bean.Resume;
import com.resume.bean.showall;
import com.resume.jdbc.jdbc;
import com.resume.util.StringUtil;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ResumeDao {

	public void add(Resume resume) {
		String sql = " insert into resume(username,sex,birth,ethnic,_native,politic,mayor,school,telephone,email,skill,experience,evaluation,userid) ";
		sql += "values('"+ resume.getUsername() + "','" + resume.getSex();
		sql += "','" + resume.getBirth() + "','" + resume.getEthnic() + "','" + resume.get_native() + "','";
		sql += resume.getPolitic() + "','" + resume.getMayor() + "','" + resume.getSchool() + "','"
				+ resume.getTelephone() + "','";
		sql += resume.getEmail() + "','" + resume.getSkill() + "','" + resume.getExperience() + "','"
				+ resume.getEvaluation() + "','" + resume.getUserid() + "');";
		System.out.println(sql);
		Connection connection = jdbc.getConn();
		Statement statement = null;
		try {
			statement = connection.createStatement();
			statement.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			jdbc.close(connection, statement, null);
		}
	}

	public void update(Resume resume) {
		String sql = " update resume set";
		sql += " username='" + resume.getUsername() + "',";
		sql += " sex='" + resume.getSex() + "',";
		sql += " birth='" + resume.getBirth() + "',";
		sql += " ethnic='" + resume.getEthnic() + "',";
		sql += " _native='" + resume.get_native() + "',";
		sql += " politic='" + resume.getPolitic() + "',";
		sql += " mayor='" + resume.getMayor() + "',";
		sql += " school='" + resume.getSchool() + "',";
		sql += " telephone='" + resume.getTelephone() + "',";
		sql += " email='" + resume.getEmail() + "',";
		sql += " skill='" + resume.getSkill() + "',";
		sql += " experience='" + resume.getExperience() + "',";
		sql += " evaluation='" + resume.getEvaluation() + "' ";
		sql += " where id='" + resume.getId() + "';";
		Connection connection = jdbc.getConn();
		Statement statement = null;
		try {
			statement = connection.createStatement();
			statement.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			jdbc.close(connection, statement, null);
		}
	}

	public void delete(String id) {
		String sql = "delete from resume where id='" + id + "';";
		Connection connection = jdbc.getConn();
		Statement statement = null;
		try {
			statement = connection.createStatement();
			statement.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			jdbc.close(connection, statement, null);
		}
	}

	public int count(String sql) {
		int a = 0;
		Connection connection = jdbc.getConn();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);
			if(resultSet.next())a = resultSet.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			jdbc.close(connection, statement, null);
		}
	    return a;
	}

	public Resume getById(String id) {
		Resume resume = null;
		String sql = "select * from resume where id='"+id+"';";
		Connection connection = jdbc.getConn();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);
			if(resultSet.next())resume  = new Resume( resultSet.getInt(1),resultSet.getString(2),
					resultSet.getString(3),resultSet.getString(4),resultSet.getString(5),resultSet.getString(6),
					resultSet.getString(7),resultSet.getString(8),resultSet.getString(9),resultSet.getString(10),
					resultSet.getString(11),resultSet.getString(12),resultSet.getString(13),resultSet.getString(14),
					resultSet.getString(15));
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			jdbc.close(connection, statement, null);
		}
	    return resume;
	}
	
	public List<Integer> getAll(String userid){
		List <Integer> list = new ArrayList<Integer>();
		String sql = "select id from resume where userid='"+userid+"';";
		Connection connection = jdbc.getConn();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);
			while(resultSet.next()){
				list.add(resultSet.getInt(1));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			jdbc.close(connection, statement, null);
		}
	    return list;
	}

	/**
	 * 查询总记录数
	 * @return
	 */

	public int findTotalCount() {
		String sql = "select count(*) from Resume";
		int totalcount = 0;

		Connection connection = jdbc.getConn();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);
			if (resultSet.next())totalcount = resultSet.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			jdbc.close(connection, statement, null);
		}

		return totalcount;
	}


	/**
	 * 分页查询每一条记录
	 * @param start
	 * @param rows
	 * @return
	 */
	public List<Resume> findByPage(int start, int rows) {
		List <Resume> list = new ArrayList<Resume>();
		String sql = "select * from resume limit "+ String.valueOf(start)+","+ String.valueOf(rows)+";";
		System.out.println("findByPage:"+sql);


		Connection connection = jdbc.getConn();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);
			while(resultSet.next()){
				Resume resume = new Resume();
				resume.setId(resultSet.getInt(1));
				resume.setUsername(resultSet.getString(2));
				resume.setSex(resultSet.getString(3));
				resume.setBirth(resultSet.getString(4));
				resume.setEthnic(resultSet.getString(5));
				resume.set_native(resultSet.getString(6));
				resume.setPolitic(resultSet.getString(7));
				resume.setMayor(resultSet.getString(8));
				resume.setSchool(resultSet.getString(9));
				resume.setTelephone(resultSet.getString(10));
				resume.setEmail(resultSet.getString(11));
				resume.setSkill(resultSet.getString(12));
				resume.setExperience(resultSet.getString(13));
				resume.setEvaluation(resultSet.getString(14));
				resume.setUserid(resultSet.getString(15));
				list.add(resume);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			jdbc.close(connection, statement, null);
		}
		return list;
	}


	public List<Resume> search(String start,String rows,String school,String mayor,String sex,String skill,String nat,String politic){
		List <Resume> list = new ArrayList<Resume>();
		String sql = "select * from resume ";
		boolean flagand = false;

		if(!StringUtil.isEmpty(school))
		{
			if (flagand == false){
				flagand = true;
				sql += " where ";
			}
			else{
				sql += " and ";
			}
			sql +="school='"+school+"'";
		}
		if(!StringUtil.isEmpty(mayor))
		{
			if (flagand == false){
				flagand = true;
				sql += " where ";
			}
			else{
				sql += " and ";
			}
			sql +="mayor='"+mayor+"'";
		}
		if(!StringUtil.isEmpty(sex))
		{
			if (flagand == false){
				flagand = true;
				sql += " where ";
			}
			else{
				sql += " and ";
			}
			sql +="sex='"+sex+"'";
		}
		if(!StringUtil.isEmpty(skill))
		{
			if (flagand == false){
				flagand = true;
				sql += " where ";
			}
			else{
				sql += " and ";
			}
			sql +="skill='"+skill+"'";
		}
		if(!StringUtil.isEmpty(nat))
		{
			if (flagand == false){
				flagand = true;
				sql += " where ";
			}
			else{
				sql += " and ";
			}
			sql +="_native='"+nat+"'";
		}
		if(!StringUtil.isEmpty(politic))
		{
			if (flagand == false){
				flagand = true;
				sql += " where ";
			}
			else{
				sql += " and ";
			}
			sql +="politic='"+politic+"'";
		}
		sql +=" limit "+start+","+rows;
		sql += ";";
		System.out.println(sql);


		Connection connection = jdbc.getConn();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);
			while(resultSet.next()){
				Resume resume = new Resume();
				resume.setId(resultSet.getInt(1));
				resume.setUsername(resultSet.getString(2));
				resume.setSex(resultSet.getString(3));
				resume.setBirth(resultSet.getString(4));
				resume.setEthnic(resultSet.getString(5));
				resume.set_native(resultSet.getString(6));
				resume.setPolitic(resultSet.getString(7));
				resume.setMayor(resultSet.getString(8));
				resume.setSchool(resultSet.getString(9));
				resume.setTelephone(resultSet.getString(10));
				resume.setEmail(resultSet.getString(11));
				resume.setSkill(resultSet.getString(12));
				resume.setExperience(resultSet.getString(13));
				resume.setEvaluation(resultSet.getString(14));
				resume.setUserid(resultSet.getString(15));
				list.add(resume);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			jdbc.close(connection, statement, null);
		}
		return list;
	}


	public int searchTotalCount(String school, String mayor, String sex, String skill, String nat, String politic) {
		String sql = "select count(*) from Resume ";

		boolean flagand = false;

		if(!StringUtil.isEmpty(school))
		{
			if (flagand == false){
				flagand = true;
				sql += " where ";
			}
			else{
				sql += " and ";
			}
			sql +="school='"+school+"'";
		}
		if(!StringUtil.isEmpty(mayor))
		{
			if (flagand == false){
				flagand = true;
				sql += " where ";
			}
			else{
				sql += " and ";
			}
			sql +="mayor='"+mayor+"'";
		}
		if(!StringUtil.isEmpty(sex))
		{
			if (flagand == false){
				flagand = true;
				sql += " where ";
			}
			else{
				sql += " and ";
			}
			sql +="sex='"+sex+"'";
		}
		if(!StringUtil.isEmpty(skill))
		{
			if (flagand == false){
				flagand = true;
				sql += " where ";
			}
			else{
				sql += " and ";
			}
			sql +="skill='"+skill+"'";
		}
		if(!StringUtil.isEmpty(nat))
		{
			if (flagand == false){
				flagand = true;
				sql += " where ";
			}
			else{
				sql += " and ";
			}
			sql +="_native='"+nat+"'";
		}
		if(!StringUtil.isEmpty(politic))
		{
			if (flagand == false){
				flagand = true;
				sql += " where ";
			}
			else{
				sql += " and ";
			}
			sql +="politic='"+politic+"'";
		}
		sql += ";";
		System.out.println(sql);

		int totalcount = 0;

		Connection connection = jdbc.getConn();
		Statement statement = null;
		ResultSet resultSet = null;
		try {
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);
			if (resultSet.next())totalcount = resultSet.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			jdbc.close(connection, statement, null);
		}

		return totalcount;
	}
}
