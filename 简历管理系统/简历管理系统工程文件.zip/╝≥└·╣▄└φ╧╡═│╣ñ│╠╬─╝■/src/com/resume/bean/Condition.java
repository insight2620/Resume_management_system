package com.resume.bean;

public class Condition {
    String school ;
    String mayor ;
    String sex ;
    String skill ;
    String nat ;
    String politic ;


    public Condition(String school, String mayor, String sex, String skill, String nat, String politic) {
        this.school = school;
        this.mayor = mayor;
        this.sex = sex;
        this.skill = skill;
        this.nat = nat;
        this.politic = politic;
    }

    @Override
    public String toString() {
        return "Condition{" +
                "school='" + school + '\'' +
                ", mayor='" + mayor + '\'' +
                ", sex='" + sex + '\'' +
                ", skill='" + skill + '\'' +
                ", nat='" + nat + '\'' +
                ", politic='" + politic + '\'' +
                '}';
    }

    public String getSchool() {
        return school;
    }

    public void setSchool(String school) {
        this.school = school;
    }

    public String getMayor() {
        return mayor;
    }

    public void setMayor(String mayor) {
        this.mayor = mayor;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getSkill() {
        return skill;
    }

    public void setSkill(String skill) {
        this.skill = skill;
    }

    public String getNat() {
        return nat;
    }

    public void setNat(String nat) {
        this.nat = nat;
    }

    public String getPolitic() {
        return politic;
    }

    public void setPolitic(String politic) {
        this.politic = politic;
    }
}
