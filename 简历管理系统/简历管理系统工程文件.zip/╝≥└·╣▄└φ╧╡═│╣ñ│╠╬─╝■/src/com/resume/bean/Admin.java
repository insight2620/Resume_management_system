package com.resume.bean;

public class Admin {
	private String userid;
	private String password;

	@Override
	public String toString() {
		return "Admin [userid=" + userid + ", password=" + password + "]";
	}
	public Admin() {
		super();
	}
	public Admin(String userid, String password) {
		super();
		this.userid = userid;
		this.password = password;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
}
