package com.resume.bean;

//resume和showall分别是管理员和用户的两条线
public class Resume {
	private int id ; 
	private String username ; 
	private String sex ; 
	private String birth ; 
	private String ethnic ; 
	private String _native ; 
	private String politic ; 
	private String mayor ; 
	private String school ; 
	private String telephone ; 
	private String email ; 
	private String skill ; 
	private String experience ; 
	private String evaluation ;
	private String userid;
	public Resume() {
		super();
	}
	public Resume(int id, String username, String sex, String birth, String ethnic, String _native, String politic,
			String mayor, String school, String telephone, String email, String skill, String experience,
			String evaluation, String userid) {
		super();
		this.id = id;
		this.username = username;
		this.sex = sex;
		this.birth = birth;
		this.ethnic = ethnic;
		this._native = _native;
		this.politic = politic;
		this.mayor = mayor;
		this.school = school;
		this.telephone = telephone;
		this.email = email;
		this.skill = skill;
		this.experience = experience;
		this.evaluation = evaluation;
		this.userid = userid;
	}
	@Override
	public String toString() {
		return "Resume [id=" + id + ", username=" + username + ", sex=" + sex + ", birth=" + birth + ", ethnic="
				+ ethnic + ", _native=" + _native + ", politic=" + politic + ", mayor=" + mayor + ", school=" + school
				+ ", telephone=" + telephone + ", email=" + email + ", skill=" + skill + ", experience=" + experience
				+ ", evaluation=" + evaluation + ", userid=" + userid + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public String getEthnic() {
		return ethnic;
	}
	public void setEthnic(String ethnic) {
		this.ethnic = ethnic;
	}
	public String get_native() {
		return _native;
	}
	public void set_native(String _native) {
		this._native = _native;
	}
	public String getPolitic() {
		return politic;
	}
	public void setPolitic(String politic) {
		this.politic = politic;
	}
	public String getMayor() {
		return mayor;
	}
	public void setMayor(String mayor) {
		this.mayor = mayor;
	}
	public String getSchool() {
		return school;
	}
	public void setSchool(String school) {
		this.school = school;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	public String getExperience() {
		return experience;
	}
	public void setExperience(String experience) {
		this.experience = experience;
	}
	public String getEvaluation() {
		return evaluation;
	}
	public void setEvaluation(String evaluation) {
		this.evaluation = evaluation;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	
}
