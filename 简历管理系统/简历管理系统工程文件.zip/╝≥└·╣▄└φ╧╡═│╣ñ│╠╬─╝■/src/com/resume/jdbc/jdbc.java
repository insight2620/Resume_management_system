package com.resume.jdbc;

import java.sql.*;

public class jdbc {
	private final static String driver="com.mysql.cj.jdbc.Driver";
	private final static String url = "jdbc:mysql://localhost:3306/stt?verifyServerCertificate=false&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC&useUnicode=true&characterEncoding=UTF-8";
	private final static String user = "root";
//	private final static String password  ="ChenHongXin.@";
	private final static String password  ="25802580";
	public static Connection getConn() {
		Connection connection = null;
		try {
			Class.forName(driver);
			connection=DriverManager.getConnection(url, user,
            password);
		} catch (ClassNotFoundException e) {
			System.out.println("数据库加载失败");
			e.printStackTrace();
		}catch (SQLException e) {
			System.out.println("数据库连接失败");
			e.printStackTrace();
		}
		return connection;
	}
	
	public static void close (Connection connection ,Statement 
    statement , ResultSet resultSet) {
		try {
			if(connection!=null)connection.close();
			if(statement!=null)statement.close();
			if(resultSet!=null)resultSet.close();
		} catch (SQLException e) {
			System.out.println("数据库关闭异常");
			e.printStackTrace();
		}
	}
	
	//娴嬭瘯鏁版嵁搴撹繛鎺ユ槸鍚︽垚鍔?
	public static void main(String []args) {
		Connection connection=null;
		connection = getConn();
		System.out.println(connection);
		close(connection, null, null);
		
	}
}
