package com.resume.servlet;

import com.resume.bean.Resume;
import com.resume.bean.User;
import com.resume.dao.ResumeDao;
import com.resume.dao.UserDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

@WebServlet("/AdminAddResume")
public class AdminAddResume extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private ResumeDao resumeDao = new ResumeDao();


	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String method = request.getParameter("method");
		//HttpSession session = request.getSession(false);


		if (method.equals("add")) {
			add(request, response);
		} else if (method.equals("show")) {
			show(request, response);
		}
	}

	protected void add(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Resume resume = getResume(request, response);
		//int resumeid = new ResumeDao().count("Select count(*) from resume;");
		//resume.setId(resumeid);
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");

		resumeDao.add(resume);
		request.setAttribute("message","add successfully");
		request.getRequestDispatcher("/Showall?method=ViewAll").forward(request, response);
	}

	protected void show(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		Resume resume = resumeDao.getById(id);
		request.setAttribute("resume", resume);
		request.getRequestDispatcher("/show.jsp").forward(request, response);
	}

	protected Resume getResume(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Resume resume = new Resume();

		resume.setUsername(request.getParameter("username"));
		resume.setSex(request.getParameter("sex"));
		resume.setBirth(request.getParameter("birth"));
		resume.setEthnic(request.getParameter("ethnic"));
		resume.set_native(request.getParameter("native"));
		resume.setPolitic(request.getParameter("politic"));
		resume.setMayor(request.getParameter("mayor"));
		resume.setSchool(request.getParameter("school"));
		resume.setTelephone(request.getParameter("telephone"));
		resume.setEmail(request.getParameter("email"));
		resume.setSkill(request.getParameter("skill"));
		resume.setExperience(request.getParameter("experience"));
		resume.setEvaluation(request.getParameter("evaluation"));
		resume.setUserid(request.getParameter("userid"));
		System.out.println(resume);
		return resume;
	}

	public static void main(String[] args) {

	}

}
