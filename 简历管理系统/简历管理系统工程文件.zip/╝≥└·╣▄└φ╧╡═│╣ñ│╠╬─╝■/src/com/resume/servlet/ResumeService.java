package com.resume.servlet;

import com.resume.bean.Resume;
import com.resume.bean.User;
import com.resume.dao.ResumeDao;
import com.resume.dao.UserDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/ResumeService")
public class ResumeService extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private ResumeDao resumeDao = new ResumeDao();
	private String userid;



	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String method = request.getParameter("method");
		HttpSession session = request.getSession(false);
		userid = (String) session.getAttribute("id");
		if(userid == null) {
			request.setAttribute("message", "Login failed");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return ;
		}
		if (method.equals("ViewAll")) {
			ViewAll(request, response);
		} else if (method.equals("updatePwd")) {
			updatePwd(request, response);
		} else if (method.equals("add")) {
			add(request, response);
		} else if (method.equals("show")) {
			show(request, response);
		}else if (method.equals("delete")) {
			delete(request, response);
		}else if (method.equals("update")) {
			update(request, response);
		}else if (method.equals("showforadmin")){
			showforadmin(request, response);
		}else if (method.equals("updateForAdmin")){
			updateForAdmin(request, response);
		}

	}

	protected void ViewAll(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<Integer>list = resumeDao.getAll(userid);//获取对应userid的resume的id
		request.setAttribute("list", list);
		request.getRequestDispatcher("/viewAll.jsp").forward(request, response);
	}

	protected void updatePwd(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String password = request.getParameter("pwd1");
		User user = new UserDao().checkId(userid);
		if(user.getPassword().equals(password)==false) {
			request.setAttribute("message", "Please enter the correct old password");
			request.getRequestDispatcher("/updatePwd.jsp").forward(request, response);
			return ;
		}
		String password2 = request.getParameter("pwd2");
		user.setPassword(password2);
		new UserDao().update(user);
		request.setAttribute("message", "successfully change password");
		request.getRequestDispatcher("/main.jsp").forward(request, response);
	}

	protected void add(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Resume resume = getResume(request, response);
		resume.setUserid(userid);
		//int resumeid = new ResumeDao().count("Select count(*) from resume;");
		//resume.setId(resumeid);
		resumeDao.add(resume);
		request.setAttribute("message", "add successfully");
		request.getRequestDispatcher("/main.jsp").forward(request, response);
	}

	protected void show(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		Resume resume = resumeDao.getById(id);
		request.setAttribute("resume", resume);
		request.getRequestDispatcher("/show.jsp").forward(request, response);
	}

	protected void showforadmin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		Resume resume = resumeDao.getById(id);
		request.setAttribute("resume", resume);
		request.getRequestDispatcher("/showForAdmin.jsp").forward(request, response);
	}
	
	protected void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		resumeDao.delete(id);
		request.setAttribute("message", "delete resume successfully");
		request.getRequestDispatcher("ResumeService?method=ViewAll").forward(request, response);
	}
	
	protected void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		Resume resume = getResume(request, response);
		resume.setId(Integer.parseInt(id));
		resumeDao.update(resume);
		request.setAttribute("message", "correct successfully");
		request.getRequestDispatcher("ResumeService?method=ViewAll").forward(request, response);
	}

	protected void updateForAdmin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		Resume resume = getResume(request, response);
		resume.setId(Integer.parseInt(id));
		resumeDao.update(resume);
		request.setAttribute("message", "correct successfully");
		request.getRequestDispatcher("Showall?method=ViewAll").forward(request, response);
	}



	protected Resume getResume(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Resume resume = new Resume();
		resume.setUsername(request.getParameter("username"));
		resume.setSex(request.getParameter("sex"));
		resume.setBirth(request.getParameter("birth"));
		resume.setEthnic(request.getParameter("ethnic"));
		resume.set_native(request.getParameter("native"));
		resume.setPolitic(request.getParameter("politic"));
		resume.setMayor(request.getParameter("mayor"));
		resume.setSchool(request.getParameter("school"));
		resume.setTelephone(request.getParameter("telephone"));
		resume.setEmail(request.getParameter("email"));
		resume.setSkill(request.getParameter("skill"));
		resume.setExperience(request.getParameter("experience"));
		resume.setEvaluation(request.getParameter("evaluation"));
		System.out.println(resume);
		return resume;
	}

	public static void main(String[] args) {

	}

}
