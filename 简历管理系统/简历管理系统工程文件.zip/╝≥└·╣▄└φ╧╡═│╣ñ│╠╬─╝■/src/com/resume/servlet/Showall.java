package com.resume.servlet;

//resumeservice??showall??????????????????????
import com.resume.bean.Resume;
import com.resume.bean.User;
import com.resume.bean.showall;
import com.resume.dao.ShowallDao;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Map;

@WebServlet("/Showall")
public class Showall extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private ShowallDao showallDao = new ShowallDao();
	private String userid;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String method = request.getParameter("method");
		HttpSession session = request.getSession(false);
		userid = (String) session.getAttribute("id");
		if(userid == null) {
			request.setAttribute("message", "User ID is empty");
			request.getRequestDispatcher("/admin.jsp").forward(request, response);
			return ;
		}
		if (method.equals("ViewAll")) {
			ViewAll(request, response);
		} else if (method.equals("show")) {
			show(request, response);
		}else if (method.equals("delete")) {
			delete(request, response);
		}else if (method.equals("update")) {
			update(request, response);
		}else if (method.equals("search")) {
			search(request, response);
		}

	}

	protected void search(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		List<String> sch  = showallDao.getconditionschool();
		request.setAttribute("ConditionSchool", sch);
		List<String> may  = showallDao.getconditionmayor();
		request.setAttribute("ConditionMayor",may );
		List<String> se  = showallDao.getconditionsex();
		request.setAttribute("ConditionSex", se);
		List<String> ski  = showallDao.getconditionskill();
		request.setAttribute("ConditionSkill",ski );
		List<String> natlist = showallDao.getcondition_native();
		request.setAttribute("Condition_native",natlist );
		List<String> politiclist  = showallDao.getconditionpolitic();
		request.setAttribute("ConditionPolitics",politiclist );


		request.getRequestDispatcher("/searchResumeByPageServlet").forward(request, response);
	}

	protected void ViewAll(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		List<String> school  = showallDao.getconditionschool();
		request.setAttribute("ConditionSchool", school);
		List<String> mayor  = showallDao.getconditionmayor();
		request.setAttribute("ConditionMayor",mayor );
		List<String> sex  = showallDao.getconditionsex();
		request.setAttribute("ConditionSex", sex);
		List<String> skill  = showallDao.getconditionskill();
		request.setAttribute("ConditionSkill",skill );
		List<String> nat = showallDao.getcondition_native();
		request.setAttribute("Condition_native",nat );
		List<String> politic  = showallDao.getconditionpolitic();
		request.setAttribute("ConditionPolitics",politic );
		//??????
//		List<showall> list2 = showallDao.getAllresume();
//		request.setAttribute("list2", list2);
//		System.out.println(list2);
		request.getRequestDispatcher("/findResumeByPageServlet").forward(request, response);
	}

	protected void show(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		Resume resume = showallDao.getById(id);
		request.setAttribute("com/resume", resume);
		request.getRequestDispatcher("/adminshow.jsp").forward(request, response);
	}
	
	protected void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		showallDao.delete(id);
		request.setAttribute("message", "delete successfully！");
		request.getRequestDispatcher("Showall?method=ViewAll").forward(request, response);
	}
	
	protected void update(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		Resume resume = getResume(request, response);
		resume.setId(Integer.parseInt(id));
		showallDao.update(resume);
		request.setAttribute("message", "correct successfully");
		request.getRequestDispatcher("Showall?method=ViewAll").forward(request, response);
	}

	protected Resume getResume(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Resume resume = new Resume();
		resume.setUsername(request.getParameter("username"));
		resume.setSex(request.getParameter("sex"));
		resume.setBirth(request.getParameter("birth"));
		resume.setEthnic(request.getParameter("ethnic"));
		resume.set_native(request.getParameter("native"));
		resume.setPolitic(request.getParameter("politic"));
		resume.setMayor(request.getParameter("mayor"));
		resume.setSchool(request.getParameter("school"));
		resume.setTelephone(request.getParameter("telephone"));
		resume.setEmail(request.getParameter("email"));
		resume.setSkill(request.getParameter("skill"));
		resume.setExperience(request.getParameter("experience"));
		resume.setEvaluation(request.getParameter("evaluation"));
		System.out.println(resume);
		return resume;
	}

}