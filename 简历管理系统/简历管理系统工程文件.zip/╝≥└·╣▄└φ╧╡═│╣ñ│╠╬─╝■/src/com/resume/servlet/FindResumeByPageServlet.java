package com.resume.servlet;

import com.resume.bean.PageBean;
import com.resume.bean.Resume;
import com.resume.service.ResumeService;
import com.resume.service.impl.ResumeServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.ws.Service;
import java.io.IOException;

@WebServlet("/findResumeByPageServlet")
public class FindResumeByPageServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

        //1.获取参数
        String currentPage = request.getParameter("currentPage");//当前页码
        String rows = request.getParameter("rows");//每页显示条数

        if(currentPage==null||"".equals(currentPage)){currentPage="1";}
        if (rows==null||"".equals(rows)){rows="10";}

        System.out.println(currentPage+rows);
        //2.调用service查询
        ResumeService service = new ResumeServiceImpl();
        PageBean<Resume> pb = service.findResumeByPage(currentPage,rows);

        System.out.println(pb);

        //3.将PageBean存入reques
        request.setAttribute("pb",pb);

        //4.转发到show_all.jsp
        request.getRequestDispatcher("/show_all.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request,response);
    }
}
