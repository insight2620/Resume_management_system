package com.resume.servlet;

import com.resume.bean.Admin;
import com.resume.dao.AdminDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/adminlogin")
public class adminlogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");

		String userid = request.getParameter("user");
		String password = request.getParameter("pwd");
		Admin Admin = new AdminDao().check(userid, password);
		if(Admin==null) {
			request.setAttribute("message", "Account error");
			request.getRequestDispatcher("/admin.jsp").forward(request, response);
		}else {
			HttpSession session = request.getSession();
			session.setAttribute("id",userid);
			request.getRequestDispatcher("/main1.jsp").forward(request, response);
		}
	}
}