package com.resume.servlet;

import com.resume.bean.User;
		import com.resume.dao.usershow;
		import org.apache.commons.beanutils.BeanUtils;

		import javax.servlet.ServletException;
		import javax.servlet.annotation.WebServlet;
		import javax.servlet.http.HttpServlet;
		import javax.servlet.http.HttpServletRequest;
		import javax.servlet.http.HttpServletResponse;
		import javax.servlet.http.HttpSession;
		import java.io.IOException;
		import java.lang.reflect.InvocationTargetException;
		import java.util.List;
		import java.util.Map;

@WebServlet("/Usershow")
public class Usershow extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private usershow usershow = new usershow();
	private String userid;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String method = request.getParameter("method");
		HttpSession session = request.getSession(false);
		userid = (String) session.getAttribute("id");
		if(userid == null) {
			request.setAttribute("message", "Login failed");
			request.getRequestDispatcher("/admin.jsp").forward(request, response);
			return ;
		}
		if (method.equals("ViewAll")) {
			ViewAll(request, response);
		}else if (method.equals("delete")) {
			delete(request, response);
		}else if (method.equals("addone")){
			try {
				addone(request,response);
			} catch (InvocationTargetException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
		}
	}

	protected void ViewAll(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<User>list = usershow.getAll();
		System.out.println(list);
		request.setAttribute("list", list);
		request.getRequestDispatcher("/usershow.jsp").forward(request, response);
	}

	protected void delete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		usershow.delete(id);
		request.setAttribute("user", "delete account successfully");
		request.getRequestDispatcher("Usershow?method=ViewAll").forward(request, response);
	}

	protected void addone(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, InvocationTargetException, IllegalAccessException {
		request.setCharacterEncoding("utf-8");
		Map<String,String[]> map = request.getParameterMap();
		System.out.println(map);
		User user = new User();
		try {
			BeanUtils.populate(user,map);
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
		System.out.println(user);
		usershow.addone(user);
		//��ת
		request.getRequestDispatcher("Usershow?method=ViewAll").forward(request, response);
	}
}