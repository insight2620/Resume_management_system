package com.resume.servlet;

import com.resume.dao.ResumeDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/DelSelectedServlet")
public class DelSelectedServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        //1.获取所有id
        String[] ids = request.getParameterValues("resumeid");
        System.out.println(ids);
        //2.调用ResumeDao删除
        ResumeDao res = new ResumeDao();
        for(String id:ids)
        {
            res.delete(id);
        }
        //3.跳转查询所有Servlet
        response.sendRedirect(request.getContextPath()+"/Showall?method=ViewAll");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request,response);
    }
}
