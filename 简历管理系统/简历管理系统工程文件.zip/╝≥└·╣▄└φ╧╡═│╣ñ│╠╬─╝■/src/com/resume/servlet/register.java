package com.resume.servlet;

import com.resume.bean.User;
import com.resume.dao.UserDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/register")
public class register extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String userid = request.getParameter("user");
		String password = request.getParameter("pwd1");
		UserDao userDao = new UserDao();
		User user = userDao.checkId(userid);
		if(user!=null) {
			request.setAttribute("message", "Username already exists.");
			request.getRequestDispatcher("/register.jsp").forward(request, response);
		}else {
			userDao.add(userid, password);
			request.setAttribute("message", "Please log after successful registration");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
		}
	}
}
