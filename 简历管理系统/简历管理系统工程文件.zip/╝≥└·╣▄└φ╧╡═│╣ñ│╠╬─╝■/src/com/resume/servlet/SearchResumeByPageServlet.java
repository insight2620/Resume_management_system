package com.resume.servlet;

import com.resume.bean.Condition;
import com.resume.bean.PageBean;
import com.resume.bean.Resume;
import com.resume.dao.ShowallDao;
import com.resume.service.ResumeService;
import com.resume.service.impl.ResumeServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/searchResumeByPageServlet")
public class SearchResumeByPageServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      request.setCharacterEncoding("UTF-8");
      response.setCharacterEncoding("UTF-8");
        //1.获取参数
        String currentPage = request.getParameter("currentPage");//当前页码
        String rows = request.getParameter("rows");//每页显示条数
        if(currentPage==null||"".equals(currentPage)){currentPage="1";}
        if (rows==null||"".equals(rows)){rows="10";}


        String school = new String(request.getParameter("school").getBytes("iso-8859-1"),"utf-8");
        String mayor = new String(request.getParameter("mayor").getBytes("iso-8859-1"),"utf-8");
        String sex = new String(request.getParameter("sex").getBytes("iso-8859-1"),"utf-8");
        String skill = new String(request.getParameter("skill").getBytes("iso-8859-1"),"utf-8");
        String nat = new String(request.getParameter("_native").getBytes("iso-8859-1"),"utf-8");
        String politic = new String(request.getParameter("politics").getBytes("iso-8859-1"),"utf-8");

        ShowallDao showallDao = new ShowallDao();
        List<String> cschool  = showallDao.getconditionschool();
        request.setAttribute("ConditionSchool", cschool);
        List<String> cmayor  = showallDao.getconditionmayor();
        request.setAttribute("ConditionMayor",cmayor );
        List<String> csex  = showallDao.getconditionsex();
        request.setAttribute("ConditionSex", csex);
        List<String> cskill  = showallDao.getconditionskill();
        request.setAttribute("ConditionSkill",cskill );
        List<String> cnat = showallDao.getcondition_native();
        request.setAttribute("Condition_native",cnat );
        List<String> cpolitic  = showallDao.getconditionpolitic();
        request.setAttribute("ConditionPolitics",cpolitic );
//        String school = request.getParameter("school");
//        String mayor = request.getParameter("mayor");
//        String sex = request.getParameter("sex");
//        String skill = request.getParameter("skill");
//        String nat = request.getParameter("_native");
//        String politic = request.getParameter("politics");



        //2.调用service查询
        ResumeService service = new ResumeServiceImpl();
        PageBean<Resume> pb = service.searchResumeByPage(currentPage,rows,school,mayor,sex,skill,nat,politic);
        System.out.println(pb);
        //3.将PageBean存入reques
        request.setAttribute("pb",pb);
        //将搜索条件保存
        Condition condition = new Condition(school,mayor,sex,skill,nat,politic);
        System.out.println("condition:"+condition);
        request.setAttribute("condition",condition);


        //4.转发到show_all.jsp
        request.getRequestDispatcher("/show_allForResult.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request,response);
    }
}

