package com.resume.service.impl;

import com.resume.bean.PageBean;
import com.resume.bean.Resume;
import com.resume.dao.ResumeDao;
import com.resume.service.ResumeService;
import com.resume.servlet.Showall;

import java.util.List;

public class ResumeServiceImpl implements ResumeService{
    @Override
    public PageBean<Resume> findResumeByPage(String _currentPage, String _rows) {

        int currentPage = Integer.parseInt(_currentPage);
        int rows = Integer.parseInt(_rows);

        //1.创建空的pageBean对象
        PageBean<Resume> pb = new PageBean<Resume>();
        //2.设置参数
        pb.setCurrentPage(currentPage);
        pb.setRows(rows);

        //3.调用dao查询总记录数
        ResumeDao dao = new ResumeDao();
        int totalCount = dao.findTotalCount();
        pb.setTotalCount(totalCount);

        //4.调用dao查询List集合
        //计算开始的记录索引
        int start = (currentPage - 1)*rows;
        List<Resume> list = dao.findByPage(start,rows);
        pb.setList(list);

        //5.计算总页码
        int totalPage = (totalCount % rows) == 0 ? totalCount/rows : totalCount/rows + 1;
        pb.setTotalPage(totalPage);

        return pb;
    }

    @Override
    public PageBean<Resume> searchResumeByPage(String _currentPage, String _rows, String school, String mayor, String sex, String skill, String nat, String politic) {
        int currentPage = Integer.parseInt(_currentPage);
        int rows = Integer.parseInt(_rows);

        //1.创建空的pageBean对象
        PageBean<Resume> pb = new PageBean<Resume>();
        //2.设置参数
        pb.setCurrentPage(currentPage);
        pb.setRows(rows);

        //3.调用dao查询总记录数
        ResumeDao dao = new ResumeDao();
        int totalCount = dao.searchTotalCount(school,mayor,sex,skill,nat,politic);
        pb.setTotalCount(totalCount);

        //4.调用dao查询List集合
        //计算开始的记录索引
        int start = (currentPage - 1)*rows;
        List<Resume> list = dao.search(String.valueOf(start),String.valueOf(rows),school,mayor,sex,skill,nat,politic);
        pb.setList(list);

        //5.计算总页码
        int totalPage = (totalCount % rows) == 0 ? totalCount/rows : totalCount/rows + 1;
        pb.setTotalPage(totalPage);

        return pb;
    }


}
