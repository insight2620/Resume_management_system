package com.resume.service;

import com.resume.bean.PageBean;
import com.resume.bean.Resume;

public interface ResumeService {
    /**
     * 分页查询
     * @param currentPage
     * @param rows
     * @return
     */
    PageBean<Resume> findResumeByPage(String currentPage, String rows);

    PageBean<Resume> searchResumeByPage(String currentPage, String rows, String school, String mayor, String sex, String skill, String nat, String politic);
}
